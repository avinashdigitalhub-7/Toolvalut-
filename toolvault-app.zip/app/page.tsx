'use client';

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { FolderPlus, Plus, Search, X, Archive } from 'lucide-react';
import { Category, Tool, ToolVaultData } from '@/lib/types';
import {
  getStoredCategories,
  getStoredTools,
  saveCategoriesToStorage,
  saveToolsToStorage,
  normalizeUrl,
} from '@/lib/storage';
import { CategoryFilter } from '@/components/CategoryFilter';
import { ToolCard } from '@/components/ToolCard';
import { ToolModal } from '@/components/ToolModal';
import { CategoryModal } from '@/components/CategoryModal';
import { ManageCategoriesModal } from '@/components/ManageCategoriesModal';
import { BackupModal } from '@/components/BackupModal';
import { DeleteConfirmModal } from '@/components/DeleteConfirmModal';
import { PWAInstallButton } from '@/components/PWAInstallButton';
import { OfflineIndicator } from '@/components/OfflineIndicator';
import { Logo } from '@/components/Logo';
import { ThemeToggle } from '@/components/ThemeToggle';
import { openExternal, registerBackButton } from '@/lib/native';

export default function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [loaded, setLoaded] = useState(false);

  // Load everything from the phone's local storage once
  useEffect(() => {
    setCategories(getStoredCategories()); // eslint-disable-line react-hooks/set-state-in-effect
    setTools(getStoredTools());
    setLoaded(true);
  }, []);

  // Search and Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [favoritesOnly, setFavoritesOnly] = useState(false);

  // Modal States
  const [isAddToolOpen, setIsAddToolOpen] = useState(false);
  const [editingTool, setEditingTool] = useState<Tool | null>(null);

  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isManageCategoriesOpen, setIsManageCategoriesOpen] = useState(false);

  const [isBackupOpen, setIsBackupOpen] = useState(false);

  // Delete Confirm State
  const [deleteTarget, setDeleteTarget] = useState<{
    type: 'tool' | 'category';
    item: Tool | Category;
  } | null>(null);

  // Persist Categories when updated
  const updateCategories = (newCategories: Category[]) => {
    setCategories(newCategories);
    saveCategoriesToStorage(newCategories);
  };

  // Persist Tools when updated
  const updateTools = (newTools: Tool[]) => {
    setTools(newTools);
    saveToolsToStorage(newTools);
  };

  // Category lookup map
  const categoryMap = useMemo(() => {
    const map = new Map<string, Category>();
    for (const c of categories) {
      map.set(c.id, c);
    }
    return map;
  }, [categories]);

  // Open Tool Handler: opens the site (in-app browser tab on phone) and tracks usage
  const handleOpenTool = (tool: Tool) => {
    openExternal(normalizeUrl(tool.url));

    const now = new Date().toISOString();
    const updated = tools.map((t) =>
      t.id === tool.id
        ? {
            ...t,
            launchCount: t.launchCount + 1,
            lastOpenedAt: now,
          }
        : t
    );
    updateTools(updated);
  };

  // Toggle Favorite
  const handleToggleFavorite = (toolId: string) => {
    const updated = tools.map((t) =>
      t.id === toolId ? { ...t, isFavorite: !t.isFavorite } : t
    );
    updateTools(updated);
  };

  // Move category of a tool
  const handleMoveToolCategory = (toolId: string, newCategoryId: string) => {
    const updated = tools.map((t) =>
      t.id === toolId ? { ...t, categoryId: newCategoryId } : t
    );
    updateTools(updated);
  };

  // Save Tool (Add or Edit)
  const handleSaveTool = (toolData: Omit<Tool, 'id' | 'createdAt'> & { id?: string }) => {
    if (toolData.id) {
      // Editing existing tool
      const updated = tools.map((t) =>
        t.id === toolData.id
          ? {
              ...t,
              url: toolData.url,
              name: toolData.name,
              description: toolData.description,
              categoryId: toolData.categoryId,
              isFavorite: toolData.isFavorite,
              launchCount: toolData.launchCount,
              lastOpenedAt: toolData.lastOpenedAt,
            }
          : t
      );
      updateTools(updated);
    } else {
      // Adding new tool
      const newTool: Tool = {
        id: `tool-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        url: toolData.url,
        name: toolData.name,
        description: toolData.description,
        categoryId: toolData.categoryId,
        isFavorite: toolData.isFavorite,
        launchCount: toolData.launchCount || 0,
        lastOpenedAt: null,
        createdAt: Date.now(),
      };
      updateTools([newTool, ...tools]);
    }
  };

  // Save Category (Add or Edit)
  const handleSaveCategory = (categoryData: { id?: string; name: string; icon: string }) => {
    if (categoryData.id) {
      // Editing
      const updated = categories.map((c) =>
        c.id === categoryData.id
          ? { ...c, name: categoryData.name, icon: categoryData.icon }
          : c
      );
      updateCategories(updated);
    } else {
      // Adding
      const newCat: Category = {
        id: `cat-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name: categoryData.name,
        icon: categoryData.icon,
        order: categories.length,
        createdAt: Date.now(),
      };
      updateCategories([...categories, newCat]);
    }
  };

  // Reorder Categories
  const handleReorderCategories = (newCategories: Category[]) => {
    updateCategories(newCategories);
  };

  // Confirm Delete
  const handleConfirmDelete = () => {
    if (!deleteTarget) return;

    if (deleteTarget.type === 'tool') {
      const toolToDelete = deleteTarget.item as Tool;
      const updated = tools.filter((t) => t.id !== toolToDelete.id);
      updateTools(updated);
    } else {
      const catToDelete = deleteTarget.item as Category;
      // Reassign tools from this category to the first available category or keep
      let remainingCats = categories.filter((c) => c.id !== catToDelete.id);
      if (remainingCats.length === 0) {
        // Always keep at least one category so tools never get orphaned
        remainingCats = [
          {
            id: `cat-${Date.now()}-general`,
            name: 'General',
            icon: 'Folder',
            order: 0,
            createdAt: Date.now(),
          },
        ];
      }
      const fallbackCatId = remainingCats[0].id;

      const updatedTools = tools.map((t) =>
        t.categoryId === catToDelete.id ? { ...t, categoryId: fallbackCatId } : t
      );
      updateTools(updatedTools);
      updateCategories(remainingCats);

      if (selectedCategoryId === catToDelete.id) {
        setSelectedCategoryId(null);
      }
    }

    setDeleteTarget(null);
  };

  // Import Backup Success Handler
  const handleImportBackup = (backupData: ToolVaultData, mode: 'merge' | 'replace') => {
    if (mode === 'replace') {
      const cats = backupData.categories.length
        ? backupData.categories
        : [{ id: 'cat-general', name: 'General', icon: 'Folder', order: 0, createdAt: Date.now() }];
      const validIds = new Set(cats.map((c) => c.id));
      updateCategories(cats);
      updateTools(
        backupData.tools.map((t) => (validIds.has(t.categoryId) ? t : { ...t, categoryId: cats[0].id }))
      );
    } else {
      // Merge
      const existingCatIds = new Set(categories.map((c) => c.id));
      const existingToolIds = new Set(tools.map((t) => t.id));

      const mergedCats = [...categories];
      for (const c of backupData.categories) {
        if (!existingCatIds.has(c.id)) {
          mergedCats.push(c);
        }
      }

      const mergedTools = [...tools];
      for (const t of backupData.tools) {
        if (!existingToolIds.has(t.id)) {
          mergedTools.push(t);
        }
      }

      const validIds = new Set(mergedCats.map((c) => c.id));
      const fallbackId = mergedCats[0]?.id || '';
      updateCategories(mergedCats);
      updateTools(
        mergedTools.map((t) => (validIds.has(t.categoryId) ? t : { ...t, categoryId: fallbackId }))
      );
    }
  };

  // Android back button: close the top-most open dialog first
  const backState = useRef<{ close: () => boolean }>({ close: () => false });
  backState.current.close = () => {
    if (deleteTarget) { setDeleteTarget(null); return true; }
    if (isAddToolOpen) { setIsAddToolOpen(false); setEditingTool(null); return true; }
    if (isAddCategoryOpen) { setIsAddCategoryOpen(false); setEditingCategory(null); return true; }
    if (isManageCategoriesOpen) { setIsManageCategoriesOpen(false); return true; }
    if (isBackupOpen) { setIsBackupOpen(false); return true; }
    return false;
  };
  useEffect(() => {
    let cleanup = () => {};
    registerBackButton(() => backState.current.close()).then((off) => {
      cleanup = off;
    });
    return () => cleanup();
  }, []);

  // Search and Filtering Logic
  const filteredTools = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return tools.filter((tool) => {
      // Favorites filter
      if (favoritesOnly && !tool.isFavorite) {
        return false;
      }

      // Category filter
      if (selectedCategoryId && tool.categoryId !== selectedCategoryId) {
        return false;
      }

      // Query filter: Tool Name, Description, Category Name, Domain
      if (q) {
        const catName = categoryMap.get(tool.categoryId)?.name.toLowerCase() || '';
        const nameMatch = tool.name.toLowerCase().includes(q);
        const descMatch = (tool.description || '').toLowerCase().includes(q);
        const catMatch = catName.includes(q);
        const urlMatch = tool.url.toLowerCase().includes(q);

        if (!nameMatch && !descMatch && !catMatch && !urlMatch) {
          return false;
        }
      }

      return true;
    });
  }, [tools, searchQuery, selectedCategoryId, favoritesOnly, categoryMap]);

  const hasFilters = !!searchQuery || selectedCategoryId !== null || favoritesOnly;
  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategoryId(null);
    setFavoritesOnly(false);
  };

  return (
    <div className="min-h-screen bg-bg text-ink flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-bg/90 backdrop-blur-md border-b border-line px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <Logo size={38} className="shrink-0 rounded-xl shadow-sm" />
            <div className="min-w-0">
              <h1 className="text-lg font-bold tracking-tight text-ink leading-tight">ToolVault</h1>
              <p className="text-[11px] text-ink3 leading-tight truncate">Your favourite tools, one tap away</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <PWAInstallButton />
            <button
              type="button"
              id="btn-open-backup-modal"
              onClick={() => setIsBackupOpen(true)}
              title="Backup & Restore"
              aria-label="Backup and restore"
              className="h-9 px-3 rounded-full inline-flex items-center gap-1.5 text-xs font-medium text-ink2 bg-surface border border-line hover:border-accent hover:text-accent transition-colors cursor-pointer"
            >
              <Archive className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Backup</span>
            </button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-5">
        {/* Primary actions */}
        <section aria-label="Primary Actions" className="grid grid-cols-2 gap-3 mb-5">
          <button
            type="button"
            id="btn-primary-add-category"
            onClick={() => {
              setEditingCategory(null);
              setIsAddCategoryOpen(true);
            }}
            className="min-h-[48px] px-4 py-3 rounded-2xl bg-surface border border-line hover:border-accent text-ink font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <FolderPlus className="w-4 h-4 text-accent" />
            <span>Add Category</span>
          </button>

          <button
            type="button"
            id="btn-primary-add-tool"
            onClick={() => {
              setEditingTool(null);
              setIsAddToolOpen(true);
            }}
            className="min-h-[48px] px-4 py-3 rounded-2xl bg-accent hover:bg-accent-hover active:bg-accent-hover text-accent-ink font-semibold text-sm flex items-center justify-center gap-2 transition-colors shadow-md shadow-accent/25 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Tool</span>
          </button>
        </section>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
          <input
            type="text"
            id="input-search-tools"
            placeholder="Search tools, categories or websites..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-3 rounded-2xl bg-surface border border-line text-ink placeholder-ink3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-colors"
          />
          {searchQuery && (
            <button
              type="button"
              id="btn-clear-search"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-lg text-ink3 hover:text-ink hover:bg-surface2 transition-colors cursor-pointer"
              title="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <CategoryFilter
          categories={categories}
          tools={tools}
          selectedCategoryId={selectedCategoryId}
          onSelectCategory={(id) => setSelectedCategoryId(id)}
          favoritesOnly={favoritesOnly}
          onToggleFavoritesOnly={() => setFavoritesOnly((v) => !v)}
          onOpenManageCategories={() => setIsManageCategoriesOpen(true)}
        />

        {/* Result info */}
        {loaded && hasFilters && (
          <div className="flex items-center justify-between gap-2 mb-3 text-xs text-ink3 px-1">
            <span>
              Showing <strong className="text-ink font-mono">{filteredTools.length}</strong> of{' '}
              <span className="font-mono">{tools.length}</span>
            </span>
            <button
              type="button"
              id="btn-reset-filters"
              onClick={resetFilters}
              className="text-xs text-accent font-medium hover:underline cursor-pointer"
            >
              Reset filters
            </button>
          </div>
        )}

        {/* Tool Cards Grid */}
        {!loaded ? null : filteredTools.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredTools.map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                category={categoryMap.get(tool.categoryId)}
                categories={categories}
                onOpen={handleOpenTool}
                onToggleFavorite={handleToggleFavorite}
                onEdit={(t) => {
                  setEditingTool(t);
                  setIsAddToolOpen(true);
                }}
                onDelete={(t) => {
                  setDeleteTarget({ type: 'tool', item: t });
                }}
                onMoveCategory={handleMoveToolCategory}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div
            id="empty-tools-state"
            className="rounded-2xl bg-surface border border-dashed border-line p-8 sm:p-12 text-center"
          >
            <div className="w-12 h-12 rounded-2xl bg-surface2 border border-line flex items-center justify-center mx-auto text-ink3 mb-3">
              <Search className="w-5 h-5 text-ink3" />
            </div>
            <h3 className="text-base font-semibold text-ink">No tools found</h3>
            <p className="mt-1 text-xs text-ink3 max-w-sm mx-auto">
              {searchQuery || selectedCategoryId || favoritesOnly
                ? 'No tools match your current search or category filter. Try clearing filters or add a new tool.'
                : 'Your tool vault is empty. Click "Add Tool" above to save your first online tool.'}
            </p>

            <div className="mt-5 flex items-center justify-center gap-3">
              {(searchQuery || selectedCategoryId || favoritesOnly) && (
                <button
                  type="button"
                  onClick={resetFilters}
                  className="px-4 py-2 rounded-xl bg-surface2 hover:bg-surface2 text-ink2 text-xs font-medium transition-colors cursor-pointer"
                >
                  Clear Filters
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setEditingTool(null);
                  setIsAddToolOpen(true);
                }}
                className="px-4 py-2 rounded-xl bg-accent hover:bg-accent-hover text-accent-ink text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Tool</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      {/* 1. Tool Modal (Add / Edit) */}
      <ToolModal
        isOpen={isAddToolOpen}
        onClose={() => {
          setIsAddToolOpen(false);
          setEditingTool(null);
        }}
        onSave={handleSaveTool}
        categories={categories}
        initialTool={editingTool}
        defaultCategoryId={selectedCategoryId || undefined}
      />

      {/* 2. Category Modal (Add / Edit) */}
      <CategoryModal
        isOpen={isAddCategoryOpen}
        onClose={() => {
          setIsAddCategoryOpen(false);
          setEditingCategory(null);
        }}
        onSave={handleSaveCategory}
        initialCategory={editingCategory}
      />

      {/* 3. Manage Categories Modal (Reorder, Edit, Delete) */}
      <ManageCategoriesModal
        isOpen={isManageCategoriesOpen}
        onClose={() => setIsManageCategoriesOpen(false)}
        categories={categories}
        tools={tools}
        onReorder={handleReorderCategories}
        onEditCategory={(cat) => {
          setEditingCategory(cat);
          setIsAddCategoryOpen(true);
        }}
        onDeleteCategory={(cat) => {
          setDeleteTarget({ type: 'category', item: cat });
        }}
        onAddNewCategory={() => {
          setEditingCategory(null);
          setIsAddCategoryOpen(true);
        }}
      />

      {/* 4. Backup & Restore Modal */}
      <BackupModal
        isOpen={isBackupOpen}
        onClose={() => setIsBackupOpen(false)}
        categories={categories}
        tools={tools}
        onImportSuccess={handleImportBackup}
      />

      {/* 5. Delete Confirmation Modal */}
      {deleteTarget && (
        <DeleteConfirmModal
          isOpen={!!deleteTarget}
          title={deleteTarget.type === 'tool' ? 'Delete Tool' : 'Delete Category'}
          message={
            deleteTarget.type === 'tool'
              ? `Are you sure you want to remove "${(deleteTarget.item as Tool).name}" from your vault? This cannot be undone.`
              : `Are you sure you want to remove the category "${(deleteTarget.item as Category).name}"?`
          }
          warningNote={
            deleteTarget.type === 'category'
              ? 'Tools currently assigned to this category will be preserved and reassigned to your default category.'
              : undefined
          }
          onConfirm={handleConfirmDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}

      {/* PWA Offline indicator */}
      <OfflineIndicator />
    </div>
  );
}
