"""Regenerates every ToolVault icon / splash PNG.  Run: python3 scripts/make_icons.py  (needs Pillow)"""
import math, os
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), '..')
PUB, ASSETS = os.path.join(ROOT, 'public'), os.path.join(ROOT, 'assets')
os.makedirs(PUB, exist_ok=True); os.makedirs(ASSETS, exist_ok=True)

C1, C2 = (138, 92, 240), (74, 34, 168)      # purple gradient
CREAM, INK = (250, 246, 238), (23, 19, 31)

def gradient(size):
    import numpy as np
    t = (np.add.outer(np.arange(size), np.arange(size)) / (2.0 * (size - 1)))[..., None]
    arr = np.array(C1) * (1 - t) + np.array(C2) * t
    return Image.fromarray(arr.astype('uint8'), 'RGB')

def logo_layer(size, scale=1.0):
    """Transparent RGBA with the vault dial centred. scale=1 -> dial radius = 168/512 of size."""
    S = 4
    big = size * S
    im = Image.new('RGBA', (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    k = big / 512 * scale
    cx = cy = big / 2
    def circ(r, fill):
        d.ellipse([cx - r * k, cy - r * k, cx + r * k, cy + r * k], fill=fill)
    circ(168, CREAM)
    for i in range(48):                                   # dial ticks
        a = math.radians(i * 7.5)
        r1, r2 = 150, 160 if i % 4 else 156
        d.line([cx + r1 * k * math.cos(a), cy + r1 * k * math.sin(a),
                cx + r2 * k * math.cos(a), cy + r2 * k * math.sin(a)], fill=INK + (110,), width=max(1, int(5 * k)))
    circ(124, INK)
    d.ellipse([cx - 30 * k, cy - 54 * k, cx + 30 * k, cy + 6 * k], fill=CREAM)           # keyhole head
    d.polygon([(cx - 18 * k, cy - 4 * k), (cx + 18 * k, cy - 4 * k), (cx + 32 * k, cy + 68 * k), (cx - 32 * k, cy + 68 * k)], fill=CREAM)
    return im.resize((size, size), Image.LANCZOS)

def rounded_mask(size, radius):
    S = 4
    m = Image.new('L', (size * S, size * S), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size * S - 1, size * S - 1], radius=radius * S, fill=255)
    return m.resize((size, size), Image.LANCZOS)

def full_icon(size, rounded=True, logo_scale=1.0):
    bg = gradient(size).convert('RGBA')
    bg.alpha_composite(logo_layer(size, logo_scale))
    if rounded:
        bg.putalpha(rounded_mask(size, int(size * 112 / 512)))
    return bg

# --- PWA / web icons
full_icon(512).save(f'{PUB}/pwa-512x512.png')
full_icon(192).save(f'{PUB}/pwa-192x192.png')
full_icon(180, rounded=False, logo_scale=0.95).save(f'{PUB}/apple-touch-icon.png')
full_icon(48).save(f'{PUB}/favicon.png')
full_icon(512, rounded=False, logo_scale=0.78).save(f'{PUB}/pwa-maskable-512x512.png')

# --- Android launcher sources for @capacitor/assets
full_icon(1024, rounded=False, logo_scale=1.0).convert('RGB').save(f'{ASSETS}/icon-only.png')
gradient(1024).save(f'{ASSETS}/icon-background.png')
logo_layer(1024, 0.78).save(f'{ASSETS}/icon-foreground.png')   # inside adaptive-icon safe zone

# --- Splash (light + dark), logo in the middle
def splash(bg, name):
    W = 2732
    im = Image.new('RGB', (W, W), bg).convert('RGBA')
    tile = full_icon(720)
    im.alpha_composite(tile, ((W - 720) // 2, (W - 720) // 2))
    im.convert('RGB').save(f'{ASSETS}/{name}')
splash(CREAM, 'splash.png')
splash((15, 13, 20), 'splash-dark.png')
print('icons generated')
