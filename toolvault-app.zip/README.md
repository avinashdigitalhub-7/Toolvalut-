# ToolVault

Personal vault for your favourite online tools. Data is stored on the phone (localStorage).

## Web / test
    npm install
    npm run dev

## Android APK (automatic)
Push this repo to GitHub. Actions -> "Build Android APK" -> download `ToolVault-apk` artifact.
