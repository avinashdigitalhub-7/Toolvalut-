export interface Category {
  id: string;
  name: string;
  icon: string; // Lucide icon identifier key
  order: number;
  createdAt: number;
}

export interface Tool {
  id: string;
  url: string;
  name: string;
  description?: string;
  categoryId: string;
  isFavorite: boolean;
  launchCount: number;
  lastOpenedAt: string | null; // ISO timestamp
  createdAt: number;
}

export interface ToolVaultData {
  version: number;
  exportedAt: string;
  categories: Category[];
  tools: Tool[];
}

export type CategoryIconName =
  | 'FileText'
  | 'Image'
  | 'Video'
  | 'Sparkles'
  | 'Code2'
  | 'Palette'
  | 'Share2'
  | 'Search'
  | 'QrCode'
  | 'Wrench'
  | 'Layers'
  | 'Zap'
  | 'Shield'
  | 'Folder'
  | 'Cpu'
  | 'Compass'
  | 'Music'
  | 'Sliders';
