import { Category, Tool, ToolVaultData } from './types';
import { saveTextFile } from './native';

const STORAGE_KEYS = {
  CATEGORIES: 'toolvault_categories_v1',
  TOOLS: 'toolvault_tools_v1',
  INITIALIZED: 'toolvault_initialized_v1',
};

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-ai',
    name: 'AI Tools',
    icon: 'Sparkles',
    order: 0,
    createdAt: 1710000000000,
  },
  {
    id: 'cat-pdf',
    name: 'PDF Tools',
    icon: 'FileText',
    order: 1,
    createdAt: 1710000001000,
  },
  {
    id: 'cat-image',
    name: 'Image Tools',
    icon: 'Image',
    order: 2,
    createdAt: 1710000002000,
  },
  {
    id: 'cat-video',
    name: 'Video Tools',
    icon: 'Video',
    order: 3,
    createdAt: 1710000003000,
  },
  {
    id: 'cat-coding',
    name: 'Coding Tools',
    icon: 'Code2',
    order: 4,
    createdAt: 1710000004000,
  },
  {
    id: 'cat-design',
    name: 'Design Tools',
    icon: 'Palette',
    order: 5,
    createdAt: 1710000005000,
  },
  {
    id: 'cat-productivity',
    name: 'Productivity Tools',
    icon: 'Layers',
    order: 6,
    createdAt: 1710000006000,
  },
];

export const INITIAL_TOOLS: Tool[] = [
  {
    id: 'tool-chatgpt',
    name: 'ChatGPT',
    url: 'https://chatgpt.com',
    description: 'Conversational generative AI model for ideation, writing, and research.',
    categoryId: 'cat-ai',
    isFavorite: true,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000010000,
  },
  {
    id: 'tool-ilovepdf',
    name: 'iLovePDF',
    url: 'https://www.ilovepdf.com',
    description: 'Compress, merge, split, and convert PDF documents in seconds.',
    categoryId: 'cat-pdf',
    isFavorite: true,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000011000,
  },
  {
    id: 'tool-tinypng',
    name: 'TinyPNG',
    url: 'https://tinypng.com',
    description: 'Smart lossy compression for WebP, PNG, and JPEG images.',
    categoryId: 'cat-image',
    isFavorite: false,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000012000,
  },
  {
    id: 'tool-removebg',
    name: 'Remove.bg',
    url: 'https://www.remove.bg',
    description: '100% automated background remover for portraits and products.',
    categoryId: 'cat-image',
    isFavorite: false,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000013000,
  },
  {
    id: 'tool-squoosh',
    name: 'Squoosh',
    url: 'https://squoosh.app',
    description: 'High-performance visual image compression with instant side-by-side preview.',
    categoryId: 'cat-image',
    isFavorite: true,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000014000,
  },
  {
    id: 'tool-123apps',
    name: '123apps Video Cutter',
    url: 'https://online-video-cutter.com',
    description: 'Trim, cut, rotate, and resize video files in your browser.',
    categoryId: 'cat-video',
    isFavorite: false,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000015000,
  },
  {
    id: 'tool-regex101',
    name: 'Regex101',
    url: 'https://regex101.com',
    description: 'Regular expression tester and debugger with detailed regex explanation.',
    categoryId: 'cat-coding',
    isFavorite: true,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000016000,
  },
  {
    id: 'tool-coolors',
    name: 'Coolors',
    url: 'https://coolors.co',
    description: 'Lightning-fast color palettes generator for designers and developers.',
    categoryId: 'cat-design',
    isFavorite: false,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000017000,
  },
  {
    id: 'tool-qrcode',
    name: 'QR Code Generator',
    url: 'https://www.qr-code-generator.com',
    description: 'Generate high-res custom QR codes for URLs, text, and Wi-Fi networks.',
    categoryId: 'cat-productivity',
    isFavorite: false,
    launchCount: 0,
    lastOpenedAt: null,
    createdAt: 1710000018000,
  },
];

export function getStoredCategories(): Category[] {
  if (typeof window === 'undefined') return INITIAL_CATEGORIES;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
      return INITIAL_CATEGORIES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_CATEGORIES;
  } catch (err) {
    console.error('Error reading categories from localStorage', err);
    return INITIAL_CATEGORIES;
  }
}

export function saveCategoriesToStorage(categories: Category[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (err) {
    console.error('Error saving categories to localStorage', err);
  }
}

export function getStoredTools(): Tool[] {
  if (typeof window === 'undefined') return INITIAL_TOOLS;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TOOLS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.TOOLS, JSON.stringify(INITIAL_TOOLS));
      return INITIAL_TOOLS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_TOOLS;
  } catch (err) {
    console.error('Error reading tools from localStorage', err);
    return INITIAL_TOOLS;
  }
}

export function saveToolsToStorage(tools: Tool[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.TOOLS, JSON.stringify(tools));
  } catch (err) {
    console.error('Error saving tools to localStorage', err);
  }
}

export function extractDomain(url: string): string {
  if (!url) return '';
  try {
    let clean = url.trim();
    if (!/^https?:\/\//i.test(clean)) {
      clean = 'https://' + clean;
    }
    const parsed = new URL(clean);
    return parsed.hostname.replace(/^www\./i, '');
  } catch {
    return url.replace(/^https?:\/\//i, '').split('/')[0] || '';
  }
}

export function normalizeUrl(url: string): string {
  let clean = url.trim();
  if (!clean) return '';
  if (!/^https?:\/\//i.test(clean)) {
    clean = 'https://' + clean;
  }
  return clean;
}

export function isValidUrl(url: string): boolean {
  try {
    const u = new URL(url);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
    return u.hostname.includes('.') || u.hostname === 'localhost';
  } catch {
    return false;
  }
}

export function getFaviconUrl(url: string): string {
  const domain = extractDomain(url);
  if (!domain) return '';
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=128`;
}

export function formatRelativeTime(isoString: string | null): string {
  if (!isoString) return 'Never';
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  
  if (diffMs < 0) return 'Just now';
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export async function exportDataAsJson(categories: Category[], tools: Tool[]): Promise<void> {
  const data: ToolVaultData = {
    version: 1,
    exportedAt: new Date().toISOString(),
    categories,
    tools,
  };
  const dateStamp = new Date().toISOString().split('T')[0];
  await saveTextFile(`toolvault-backup-${dateStamp}.json`, JSON.stringify(data, null, 2));
}

export function validateBackupJson(jsonString: string): { valid: boolean; data?: ToolVaultData; error?: string } {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') {
      return { valid: false, error: 'Invalid JSON structure' };
    }
    if (!Array.isArray(parsed.categories) || !Array.isArray(parsed.tools)) {
      return { valid: false, error: 'Backup must contain valid categories and tools arrays' };
    }

    const categories: Category[] = parsed.categories
      .filter((c: any) => c && typeof c.id === 'string' && typeof c.name === 'string')
      .map((c: any, i: number) => ({
        id: c.id,
        name: c.name,
        icon: typeof c.icon === 'string' ? c.icon : 'Folder',
        order: typeof c.order === 'number' ? c.order : i,
        createdAt: typeof c.createdAt === 'number' ? c.createdAt : Date.now(),
      }));

    const tools: Tool[] = parsed.tools
      .filter((t: any) => t && typeof t.id === 'string' && typeof t.name === 'string' && typeof t.url === 'string')
      .map((t: any) => ({
        id: t.id,
        name: t.name,
        url: t.url,
        description: typeof t.description === 'string' ? t.description : undefined,
        categoryId: typeof t.categoryId === 'string' ? t.categoryId : '',
        isFavorite: !!t.isFavorite,
        launchCount: typeof t.launchCount === 'number' ? t.launchCount : 0,
        lastOpenedAt: typeof t.lastOpenedAt === 'string' ? t.lastOpenedAt : null,
        createdAt: typeof t.createdAt === 'number' ? t.createdAt : Date.now(),
      }));

    return {
      valid: true,
      data: { version: 1, exportedAt: parsed.exportedAt || '', categories, tools },
    };
  } catch (err: any) {
    return { valid: false, error: err?.message || 'JSON parse error' };
  }
}
