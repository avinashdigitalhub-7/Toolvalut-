import { Capacitor } from '@capacitor/core';

/** True only when running inside the installed Android/iOS app (Capacitor). */
export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** Opens a website. Inside the app it uses an in-app browser tab (back button returns to ToolVault). */
export async function openExternal(url: string): Promise<void> {
  if (isNativeApp()) {
    try {
      const { Browser } = await import('@capacitor/browser');
      await Browser.open({ url });
      return;
    } catch (err) {
      console.error('Browser.open failed, falling back to window.open', err);
    }
  }
  window.open(url, '_blank', 'noopener,noreferrer');
}

/** Saves a text file. In the app: writes to cache and opens the Android share sheet (Save to Drive / Files / WhatsApp...). */
export async function saveTextFile(filename: string, content: string, mime = 'application/json'): Promise<void> {
  if (isNativeApp()) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const written = await Filesystem.writeFile({
      path: filename,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    await Share.share({
      title: 'ToolVault backup',
      dialogTitle: 'Save your ToolVault backup',
      url: written.uri,
    });
    return;
  }
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/** Keeps the Android status bar in sync with the app theme. */
export async function syncStatusBar(theme: 'light' | 'dark'): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setStyle({ style: theme === 'dark' ? Style.Dark : Style.Light });
    if (Capacitor.getPlatform() === 'android') {
      await StatusBar.setBackgroundColor({ color: theme === 'dark' ? '#0f0d14' : '#faf6ee' });
    }
  } catch {
    /* plugin not available: ignore */
  }
}

/** Android hardware back button: close modal if one is open, otherwise minimize the app. */
export async function registerBackButton(handler: () => boolean): Promise<() => void> {
  if (!isNativeApp()) return () => {};
  try {
    const { App } = await import('@capacitor/app');
    const sub = await App.addListener('backButton', () => {
      const handled = handler();
      if (!handled) App.minimizeApp();
    });
    return () => {
      sub.remove();
    };
  } catch {
    return () => {};
  }
}
