import React from 'react';

/** ToolVault logo: purple tile, cream vault dial, black keyhole. */
export const Logo: React.FC<{ size?: number; className?: string }> = ({ size = 36, className }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 512 512"
    className={className}
    role="img"
    aria-label="ToolVault"
  >
    <defs>
      <linearGradient id="tvLogoBg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#8a5cf0" />
        <stop offset="1" stopColor="#4a22a8" />
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="112" fill="url(#tvLogoBg)" />
    <circle cx="256" cy="256" r="168" fill="#faf6ee" />
    <circle cx="256" cy="256" r="168" fill="none" stroke="#17131f" strokeWidth="14" strokeDasharray="6 22" strokeLinecap="round" opacity=".35" />
    <circle cx="256" cy="256" r="124" fill="#17131f" />
    <circle cx="256" cy="232" r="30" fill="#faf6ee" />
    <path d="M238 252 h36 l14 70 h-64 z" fill="#faf6ee" />
  </svg>
);
