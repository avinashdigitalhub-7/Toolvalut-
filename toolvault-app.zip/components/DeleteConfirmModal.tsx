'use client';

import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  warningNote?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  title,
  message,
  warningNote,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 tv-fade">
      <div
        id="delete-confirm-dialog"
        className="w-full max-w-sm rounded-2xl bg-surface border border-line p-5 shadow-2xl relative"
      >
        <div className="flex items-center justify-between pb-3 border-b border-line">
          <h3 className="text-sm font-bold text-ink flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-danger" />
            {title}
          </h3>
          <button
            type="button"
            onClick={onCancel}
            className="p-1 text-ink3 hover:text-ink rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="mt-3 text-xs text-ink2 leading-relaxed">{message}</p>

        {warningNote && (
          <div className="mt-2.5 p-2.5 rounded-xl bg-accent-soft border border-star/40 text-star text-[11px] leading-snug">
            {warningNote}
          </div>
        )}

        <div className="mt-5 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-3.5 py-2 rounded-xl border border-line text-ink2 hover:bg-surface2 text-xs font-medium transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            id="btn-confirm-delete"
            onClick={onConfirm}
            className="px-4 py-2 rounded-xl bg-danger hover:bg-danger text-accent-ink text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-accent/20"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>
    </div>
  );
};
