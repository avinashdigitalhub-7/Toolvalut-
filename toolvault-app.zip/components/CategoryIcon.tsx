import React from 'react';
import {
  FileText,
  Image as ImageIcon,
  Video,
  Sparkles,
  Code2,
  Palette,
  Share2,
  Search,
  QrCode,
  Wrench,
  Layers,
  Zap,
  Shield,
  Folder,
  Cpu,
  Compass,
  Music,
  Sliders,
  LucideProps,
} from 'lucide-react';
import { CategoryIconName } from '@/lib/types';

export const AVAILABLE_CATEGORY_ICONS: { name: CategoryIconName; label: string; icon: React.FC<LucideProps> }[] = [
  { name: 'Sparkles', label: 'AI & Smart', icon: Sparkles },
  { name: 'FileText', label: 'PDF & Docs', icon: FileText },
  { name: 'Image', label: 'Image & Photos', icon: ImageIcon },
  { name: 'Video', label: 'Video & Audio', icon: Video },
  { name: 'Code2', label: 'Coding & Dev', icon: Code2 },
  { name: 'Palette', label: 'Design & Colors', icon: Palette },
  { name: 'Layers', label: 'Productivity', icon: Layers },
  { name: 'Wrench', label: 'Utilities', icon: Wrench },
  { name: 'QrCode', label: 'QR & Barcode', icon: QrCode },
  { name: 'Search', label: 'SEO & Search', icon: Search },
  { name: 'Share2', label: 'Social & Sharing', icon: Share2 },
  { name: 'Zap', label: 'Fast & Automation', icon: Zap },
  { name: 'Shield', label: 'Security & Privacy', icon: Shield },
  { name: 'Folder', label: 'General / Vault', icon: Folder },
  { name: 'Cpu', label: 'Hardware & Tech', icon: Cpu },
  { name: 'Compass', label: 'Explore & Web', icon: Compass },
  { name: 'Music', label: 'Audio & Music', icon: Music },
  { name: 'Sliders', label: 'Settings & Config', icon: Sliders },
];

interface CategoryIconProps extends LucideProps {
  name: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, ...props }) => {
  switch (name) {
    case 'FileText':
      return <FileText {...props} />;
    case 'Image':
      return <ImageIcon {...props} />;
    case 'Video':
      return <Video {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'Code2':
      return <Code2 {...props} />;
    case 'Palette':
      return <Palette {...props} />;
    case 'Share2':
      return <Share2 {...props} />;
    case 'Search':
      return <Search {...props} />;
    case 'QrCode':
      return <QrCode {...props} />;
    case 'Wrench':
      return <Wrench {...props} />;
    case 'Layers':
      return <Layers {...props} />;
    case 'Zap':
      return <Zap {...props} />;
    case 'Shield':
      return <Shield {...props} />;
    case 'Folder':
      return <Folder {...props} />;
    case 'Cpu':
      return <Cpu {...props} />;
    case 'Compass':
      return <Compass {...props} />;
    case 'Music':
      return <Music {...props} />;
    case 'Sliders':
      return <Sliders {...props} />;
    default:
      return <Folder {...props} />;
  }
};
