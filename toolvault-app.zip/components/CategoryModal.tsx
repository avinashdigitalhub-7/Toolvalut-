'use client';

import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { Category } from '@/lib/types';
import { AVAILABLE_CATEGORY_ICONS, CategoryIcon } from './CategoryIcon';

interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (categoryData: { id?: string; name: string; icon: string }) => void;
  initialCategory?: Category | null;
}

interface CategoryModalFormProps {
  initialCategory?: Category | null;
  onClose: () => void;
  onSave: (categoryData: { id?: string; name: string; icon: string }) => void;
}

const CategoryModalForm: React.FC<CategoryModalFormProps> = ({
  initialCategory,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState(initialCategory?.name || '');
  const [selectedIcon, setSelectedIcon] = useState(initialCategory?.icon || 'Folder');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a category name');
      return;
    }

    onSave({
      id: initialCategory?.id,
      name: name.trim(),
      icon: selectedIcon,
    });
    onClose();
  };

  return (
    <div
      id="category-modal-dialog"
      className="w-full max-w-md rounded-2xl bg-surface border border-line p-5 sm:p-6 shadow-2xl my-8 relative"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-line">
        <div>
          <h2 className="text-lg font-bold text-ink">
            {initialCategory ? 'Edit Category' : 'Add New Category'}
          </h2>
          <p className="text-xs text-ink3 mt-0.5">
            {initialCategory ? 'Update category name and icon' : 'Group your tools for fast access'}
          </p>
        </div>
        <button
          type="button"
          id="btn-close-category-modal"
          onClick={onClose}
          className="min-w-[36px] min-h-[36px] rounded-lg text-ink3 hover:text-ink hover:bg-surface2 flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {error && (
        <div className="mt-3 p-3 rounded-xl bg-danger-soft border border-danger/40 text-danger text-xs font-medium">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        {/* Category Name */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Category Name <span className="text-accent">*</span>
          </label>
          <input
            type="text"
            id="input-category-name"
            required
            placeholder="e.g. PDF Tools, AI Tools, Social Media Tools"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-bg border border-line text-ink placeholder-ink3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-colors font-medium"
          />
        </div>

        {/* Icon Selector Grid */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Choose Icon
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1.5 bg-bg rounded-xl border border-line">
            {AVAILABLE_CATEGORY_ICONS.map((item) => {
              const isSelected = selectedIcon === item.name;
              return (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => setSelectedIcon(item.name)}
                  className={`flex flex-col items-center justify-center gap-1.5 p-2 rounded-xl text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-accent text-accent-ink ring-2 ring-accent font-semibold shadow-sm'
                      : 'bg-surface text-ink2 hover:bg-surface2 hover:text-ink border border-line'
                  }`}
                >
                  <CategoryIcon
                    name={item.name}
                    className={`w-5 h-5 ${isSelected ? 'text-accent-ink' : 'text-ink3'}`}
                  />
                  <span className="text-[10px] truncate max-w-full leading-tight">
                    {item.label.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="pt-2 flex items-center justify-end gap-2.5">
          <button
            type="button"
            id="btn-cancel-category"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-line text-ink2 hover:bg-surface2 hover:text-ink text-xs font-medium transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="btn-save-category"
            className="px-5 py-2.5 rounded-xl bg-accent hover:bg-accent-hover active:bg-accent-hover text-accent-ink text-xs font-semibold shadow-md shadow-accent/20 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>{initialCategory ? 'Save Changes' : 'Create Category'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export const CategoryModal: React.FC<CategoryModalProps> = (props) => {
  if (!props.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto tv-fade">
      <CategoryModalForm
        key={props.initialCategory?.id || 'new-category'}
        initialCategory={props.initialCategory}
        onClose={props.onClose}
        onSave={props.onSave}
      />
    </div>
  );
};
