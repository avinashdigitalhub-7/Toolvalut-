'use client';

import React, { useState } from 'react';
import { Download, Share, X, Check } from 'lucide-react';
import { usePWAInstall } from '@/hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [installedNotice, setInstalledNotice] = useState(false);

  // If already running inside standalone app, hide
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop install
  if (isInstallable) {
    return (
      <>
        <button
          type="button"
          id="btn-pwa-install"
          onClick={async () => {
            const success = await install();
            if (success) {
              setInstalledNotice(true);
              setTimeout(() => setInstalledNotice(false), 4000);
            }
          }}
          title="Install ToolVault on your device"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-accent bg-accent-soft border border-accent hover:bg-accent-soft transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Install App</span>
          <span className="sm:hidden">Install</span>
        </button>

        {installedNotice && (
          <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-accent-soft text-accent border border-accent px-4 py-2.5 rounded-xl shadow-xl text-xs font-medium tv-pop">
            <Check className="w-4 h-4 text-accent" />
            <span>ToolVault installed successfully!</span>
          </div>
        )}
      </>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          type="button"
          id="btn-pwa-ios"
          onClick={() => setShowIOSGuide(true)}
          title="Install on iPhone / iPad"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-ink2 bg-surface2 border border-line hover:bg-surface2 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-ink3" />
          <span className="hidden sm:inline">Add to Home</span>
          <span className="sm:hidden">Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 tv-fade">
            <div className="w-full max-w-sm rounded-2xl bg-surface border border-line p-5 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-line">
                <h3 className="text-sm font-semibold text-ink flex items-center gap-2">
                  <Download className="w-4 h-4 text-accent" />
                  Install ToolVault on iOS
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-ink3 hover:text-ink rounded-md"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-xs text-ink2">
                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-surface2 border border-line">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-surface2 text-accent font-bold flex items-center justify-center text-xs">
                    1
                  </span>
                  <p>
                    Tap the <strong className="text-ink">Share</strong> button <Share className="w-3.5 h-3.5 inline mx-1 text-accent" /> at the bottom of Safari.
                  </p>
                </div>
                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-surface2 border border-line">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-surface2 text-accent font-bold flex items-center justify-center text-xs">
                    2
                  </span>
                  <p>
                    Scroll down and select <strong className="text-ink">Add to Home Screen</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-surface2 border border-line">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-surface2 text-accent font-bold flex items-center justify-center text-xs">
                    3
                  </span>
                  <p>
                    Tap <strong className="text-ink">Add</strong> in the top-right corner to launch ToolVault like a native app.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full py-2.5 rounded-xl bg-accent hover:bg-accent-hover font-medium text-xs text-accent-ink transition-colors cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
