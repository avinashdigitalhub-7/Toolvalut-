'use client';

import React from 'react';
import {
  X,
  ArrowUp,
  ArrowDown,
  Pencil,
  Trash2,
  Plus,
  Layers,
  AlertTriangle,
} from 'lucide-react';
import { Category, Tool } from '@/lib/types';
import { CategoryIcon } from './CategoryIcon';

interface ManageCategoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  tools: Tool[];
  onReorder: (newCategories: Category[]) => void;
  onEditCategory: (category: Category) => void;
  onDeleteCategory: (category: Category) => void;
  onAddNewCategory: () => void;
}

export const ManageCategoriesModal: React.FC<ManageCategoriesModalProps> = ({
  isOpen,
  onClose,
  categories,
  tools,
  onReorder,
  onEditCategory,
  onDeleteCategory,
  onAddNewCategory,
}) => {
  if (!isOpen) return null;

  // Move category up
  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const copy = [...categories];
    const item = copy[index];
    copy[index] = copy[index - 1];
    copy[index - 1] = item;
    // update order
    const updated = copy.map((c, idx) => ({ ...c, order: idx }));
    onReorder(updated);
  };

  // Move category down
  const handleMoveDown = (index: number) => {
    if (index === categories.length - 1) return;
    const copy = [...categories];
    const item = copy[index];
    copy[index] = copy[index + 1];
    copy[index + 1] = item;
    // update order
    const updated = copy.map((c, idx) => ({ ...c, order: idx }));
    onReorder(updated);
  };

  // Tool count per category
  const toolCounts: Record<string, number> = {};
  for (const t of tools) {
    toolCounts[t.categoryId] = (toolCounts[t.categoryId] || 0) + 1;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto tv-fade">
      <div
        id="manage-categories-dialog"
        className="w-full max-w-lg rounded-2xl bg-surface border border-line p-5 sm:p-6 shadow-2xl my-8 relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-line">
          <div>
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              <Layers className="w-5 h-5 text-accent" />
              Manage & Reorder Categories
            </h2>
            <p className="text-xs text-ink3 mt-0.5">
              Change the order, rename, or remove categories
            </p>
          </div>
          <button
            type="button"
            id="btn-close-manage-categories"
            onClick={onClose}
            className="min-w-[36px] min-h-[36px] rounded-lg text-ink3 hover:text-ink hover:bg-surface2 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories List */}
        <div className="mt-4 max-h-[60vh] overflow-y-auto space-y-2 pr-1">
          {categories.length === 0 ? (
            <div className="text-center py-8 text-ink3 text-xs">
              No categories created yet. Click below to add one.
            </div>
          ) : (
            categories.map((cat, idx) => {
              const count = toolCounts[cat.id] || 0;
              const isFirst = idx === 0;
              const isLast = idx === categories.length - 1;

              return (
                <div
                  key={cat.id}
                  id={`manage-cat-item-${cat.id}`}
                  className="flex items-center justify-between gap-3 p-3 rounded-xl bg-bg/80 border border-line hover:border-line transition-colors"
                >
                  {/* Category info */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-8 h-8 rounded-lg bg-surface2 border border-line flex items-center justify-center text-accent shrink-0">
                      <CategoryIcon name={cat.icon} className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-ink truncate">{cat.name}</div>
                      <div className="text-[11px] text-ink3">
                        {count} {count === 1 ? 'tool' : 'tools'}
                      </div>
                    </div>
                  </div>

                  {/* Actions: Move Up / Down, Edit, Delete */}
                  <div className="flex items-center gap-1 shrink-0">
                    {/* Move Up */}
                    <button
                      type="button"
                      disabled={isFirst}
                      onClick={() => handleMoveUp(idx)}
                      title="Move up"
                      className={`min-w-[34px] min-h-[34px] rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                        isFirst
                          ? 'text-ink3 cursor-not-allowed'
                          : 'text-ink3 hover:text-ink hover:bg-surface2'
                      }`}
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>

                    {/* Move Down */}
                    <button
                      type="button"
                      disabled={isLast}
                      onClick={() => handleMoveDown(idx)}
                      title="Move down"
                      className={`min-w-[34px] min-h-[34px] rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                        isLast
                          ? 'text-ink3 cursor-not-allowed'
                          : 'text-ink3 hover:text-ink hover:bg-surface2'
                      }`}
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>

                    {/* Edit */}
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onEditCategory(cat);
                      }}
                      title="Edit Category"
                      className="min-w-[34px] min-h-[34px] rounded-lg flex items-center justify-center text-ink3 hover:text-accent hover:bg-surface2 transition-colors cursor-pointer"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => {
                        onDeleteCategory(cat);
                      }}
                      title="Delete Category"
                      className="min-w-[34px] min-h-[34px] rounded-lg flex items-center justify-center text-ink3 hover:text-danger hover:bg-danger-soft transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Actions */}
        <div className="mt-5 pt-4 border-t border-line flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              onClose();
              onAddNewCategory();
            }}
            className="px-3.5 py-2 rounded-xl bg-surface2 hover:bg-surface2 text-ink text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-accent" />
            <span>Add New Category</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-accent hover:bg-accent-hover text-accent-ink text-xs font-semibold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
