'use client';

import React, { useState, useRef } from 'react';
import {
  X,
  Download,
  Upload,
  FileJson,
  CheckCircle2,
  AlertCircle,
  FolderArchive,
} from 'lucide-react';
import { Category, Tool, ToolVaultData } from '@/lib/types';
import { exportDataAsJson, validateBackupJson } from '@/lib/storage';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  tools: Tool[];
  onImportSuccess: (importedData: ToolVaultData, mode: 'merge' | 'replace') => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({
  isOpen,
  onClose,
  categories,
  tools,
  onImportSuccess,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ToolVaultData | null>(null);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleClose = () => {
    setSelectedFile(null);
    setParsedData(null);
    setError(null);
    setSuccessMsg(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onClose();
  };

  if (!isOpen) return null;

  const handleExport = async () => {
    setError(null);
    try {
      await exportDataAsJson(categories, tools);
      setSuccessMsg('Backup ready! Save it to Drive / Files so you never lose your vault.');
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (err) {
      console.error(err);
      setError('Could not create the backup file. Please try again.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setSuccessMsg(null);
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const result = validateBackupJson(content);
      if (result.valid && result.data) {
        setParsedData(result.data);
      } else {
        setError(result.error || 'Invalid ToolVault backup JSON');
        setParsedData(null);
      }
    };
    reader.onerror = () => {
      setError('Failed to read backup file');
      setParsedData(null);
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = () => {
    if (!parsedData) return;
    onImportSuccess(parsedData, importMode);
    setSuccessMsg(
      `Import completed! Successfully loaded ${parsedData.categories.length} categories and ${parsedData.tools.length} tools.`
    );
    setTimeout(() => {
      handleClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto tv-fade">
      <div
        id="backup-modal-dialog"
        className="w-full max-w-md rounded-2xl bg-surface border border-line p-5 sm:p-6 shadow-2xl my-8 relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-line">
          <div>
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-accent" />
              Backup & Restore Vault
            </h2>
            <p className="text-xs text-ink3 mt-0.5">
              Export your data or switch devices with JSON
            </p>
          </div>
          <button
            type="button"
            id="btn-close-backup-modal"
            onClick={handleClose}
            className="min-w-[36px] min-h-[36px] rounded-lg text-ink3 hover:text-ink hover:bg-surface2 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Alerts */}
        {successMsg && (
          <div className="mt-4 p-3 rounded-xl bg-accent-soft border border-accent text-accent text-xs font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-accent shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-danger-soft border border-danger/40 text-danger text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-danger shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Section 1: Export Data */}
        <div className="mt-5 p-4 rounded-xl bg-bg border border-line">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-semibold text-ink">Export Vault Data</h3>
              <p className="text-[11px] text-ink3">
                Current: {categories.length} categories, {tools.length} tools
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-export-json"
            onClick={handleExport}
            className="w-full mt-2 py-2.5 px-4 rounded-xl bg-surface2 hover:bg-surface2 text-ink text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-accent" />
            <span>Download JSON Backup</span>
          </button>
        </div>

        {/* Section 2: Import Data */}
        <div className="mt-4 p-4 rounded-xl bg-bg border border-line">
          <h3 className="text-sm font-semibold text-ink mb-1">Import from JSON Backup</h3>
          <p className="text-[11px] text-ink3 mb-3">
            Select a previously exported ToolVault JSON file
          </p>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            type="button"
            id="btn-choose-file"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 px-4 rounded-xl border border-dashed border-line hover:border-accent bg-surface hover:bg-surface text-ink2 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <FileJson className="w-4 h-4 text-accent" />
            <span>{selectedFile ? selectedFile.name : 'Choose JSON Backup File'}</span>
          </button>

          {parsedData && (
            <div className="mt-3 p-3 rounded-lg bg-surface border border-accent space-y-2 text-xs">
              <div className="text-accent font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Valid Backup Detected
              </div>
              <div className="text-ink2 text-[11px]">
                Found: <strong className="text-ink">{parsedData.categories.length}</strong> categories and <strong className="text-ink">{parsedData.tools.length}</strong> tools.
              </div>

              {/* Merge vs Replace Mode */}
              <div className="pt-2 border-t border-line">
                <div className="text-[11px] font-semibold text-ink2 uppercase tracking-wider mb-1.5">
                  Import Action
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setImportMode('merge')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-colors cursor-pointer text-center ${
                      importMode === 'merge'
                        ? 'bg-accent text-accent-ink ring-1 ring-accent font-semibold'
                        : 'bg-surface2 text-ink2 hover:bg-surface2'
                    }`}
                  >
                    Merge (Keep Existing)
                  </button>
                  <button
                    type="button"
                    onClick={() => setImportMode('replace')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-colors cursor-pointer text-center ${
                      importMode === 'replace'
                        ? 'bg-danger text-accent-ink ring-1 ring-danger font-semibold'
                        : 'bg-surface2 text-ink2 hover:bg-surface2'
                    }`}
                  >
                    Replace Everything
                  </button>
                </div>
              </div>

              <button
                type="button"
                id="btn-confirm-import"
                onClick={handleExecuteImport}
                className="w-full mt-2 py-2.5 px-4 rounded-xl bg-accent hover:bg-accent-hover text-accent-ink text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-md shadow-accent/20 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Confirm & Apply Import</span>
              </button>
            </div>
          )}
        </div>

        {/* Close Button */}
        <div className="mt-5 pt-3 border-t border-line flex justify-end">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 rounded-xl bg-surface2 hover:bg-surface2 text-ink2 text-xs font-medium transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
