'use client';

import React, { useState } from 'react';
import {
  Star,
  ExternalLink,
  MoreVertical,
  Pencil,
  Trash2,
  FolderSync,
  Globe,
} from 'lucide-react';
import { Category, Tool } from '@/lib/types';
import { getFaviconUrl, extractDomain } from '@/lib/storage';
import { CategoryIcon } from './CategoryIcon';

interface ToolCardProps {
  tool: Tool;
  category?: Category;
  categories: Category[];
  onOpen: (tool: Tool) => void;
  onToggleFavorite: (toolId: string) => void;
  onEdit: (tool: Tool) => void;
  onDelete: (tool: Tool) => void;
  onMoveCategory: (toolId: string, newCategoryId: string) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({
  tool,
  category,
  categories,
  onOpen,
  onToggleFavorite,
  onEdit,
  onDelete,
  onMoveCategory,
}) => {
  const [faviconError, setFaviconError] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showMovePicker, setShowMovePicker] = useState(false);

  React.useEffect(() => {
    setFaviconError(false);
  }, [tool.url]);

  const domain = extractDomain(tool.url);
  const faviconSrc = getFaviconUrl(tool.url);

  // Close menu on click outside
  React.useEffect(() => {
    if (!showMenu && !showMovePicker) return;
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest(`#tool-card-menu-${tool.id}`)) {
        setShowMenu(false);
        setShowMovePicker(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [showMenu, showMovePicker, tool.id]);

  return (
    <div
      id={`tool-card-${tool.id}`}
      className="group relative flex flex-col justify-between rounded-2xl bg-surface border border-line p-4 transition-colors duration-200 hover:border-accent/60 shadow-sm"
    >
      {/* Top Header Row: Favicon + Name + Favorite + Menu */}
      <div>
        <div className="flex items-start justify-between gap-2.5">
          <div className="flex items-start gap-3 min-w-0 flex-1">
            {/* Favicon / Fallback */}
            <div className="relative w-10 h-10 rounded-xl bg-surface2 border border-line flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
              {!faviconError && faviconSrc ? (
                /* eslint-disable-next-line @next/next/no-img-element */
                <img
                  src={faviconSrc}
                  alt={`${tool.name} favicon`}
                  onError={() => setFaviconError(true)}
                  className="w-5 h-5 object-contain"
                  loading="lazy"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-surface2 text-ink2 font-bold text-sm uppercase">
                  {tool.name.charAt(0) || <Globe className="w-4 h-4 text-ink3" />}
                </div>
              )}
            </div>

            {/* Tool Name & Domain */}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h3
                  onClick={() => onOpen(tool)}
                  className="text-base font-semibold text-ink truncate cursor-pointer hover:text-accent transition-colors"
                  title={tool.name}
                >
                  {tool.name}
                </h3>
              </div>
              <p className="text-[11px] text-ink3 truncate font-mono mt-0.5">
                {domain || tool.url}
              </p>
            </div>
          </div>

          {/* Actions: Favorite Star & Context Menu */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Favorite Toggle Button */}
            <button
              type="button"
              id={`btn-fav-${tool.id}`}
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(tool.id);
              }}
              title={tool.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
              aria-label={tool.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
              className={`min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                tool.isFavorite
                  ? 'text-star bg-star/10 hover:bg-star/20'
                  : 'text-ink3 hover:text-ink2 hover:bg-surface2'
              }`}
            >
              <Star
                className={`w-4 h-4 ${tool.isFavorite ? 'fill-star text-star' : ''}`}
              />
            </button>

            {/* 3-Dots Menu */}
            <div className="relative" id={`tool-card-menu-${tool.id}`}>
              <button
                type="button"
                id={`btn-more-${tool.id}`}
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(!showMenu);
                  setShowMovePicker(false);
                }}
                title="More options"
                aria-label="Tool options"
                className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-ink3 hover:text-ink2 hover:bg-surface2 transition-colors cursor-pointer"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {/* Dropdown Options */}
              {showMenu && (
                <div className="absolute right-0 top-11 z-30 w-44 rounded-xl bg-surface border border-line p-1.5 shadow-2xl backdrop-blur-md tv-pop">
                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      onEdit(tool);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-ink2 hover:text-ink hover:bg-surface2 rounded-lg transition-colors cursor-pointer text-left"
                  >
                    <Pencil className="w-3.5 h-3.5 text-ink3" />
                    Edit Tool
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowMovePicker(!showMovePicker);
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-ink2 hover:text-ink hover:bg-surface2 rounded-lg transition-colors cursor-pointer text-left"
                  >
                    <div className="flex items-center gap-2">
                      <FolderSync className="w-3.5 h-3.5 text-ink3" />
                      Move Category
                    </div>
                    <span className="text-[10px] text-ink3">›</span>
                  </button>

                  {/* Sub-menu for moving category */}
                  {showMovePicker && (
                    <div className="my-1 py-1 border-y border-line bg-bg/60 rounded-md">
                      <div className="px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-ink3">
                        Choose Category
                      </div>
                      <div className="max-h-36 overflow-y-auto space-y-0.5 px-1">
                        {categories.map((c) => (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => {
                              onMoveCategory(tool.id, c.id);
                              setShowMenu(false);
                              setShowMovePicker(false);
                            }}
                            className={`w-full flex items-center gap-2 px-2 py-1.5 text-xs rounded transition-colors text-left ${
                              tool.categoryId === c.id
                                ? 'bg-accent-soft text-accent font-semibold'
                                : 'text-ink2 hover:bg-surface2 hover:text-ink'
                            }`}
                          >
                            <CategoryIcon name={c.icon} className="w-3 h-3 text-ink3" />
                            <span className="truncate">{c.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="h-px bg-surface2 my-1" />

                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      onDelete(tool);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-danger hover:text-danger hover:bg-danger-soft rounded-lg transition-colors cursor-pointer text-left"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-danger" />
                    Delete Tool
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Description */}
        {tool.description ? (
          <p className="mt-2.5 text-xs text-ink2 line-clamp-2 leading-relaxed font-normal">
            {tool.description}
          </p>
        ) : (
          <p className="mt-2.5 text-xs text-ink3 italic">No description provided</p>
        )}
      </div>

      {/* Card Footer: Category badge + Launch Count + Open Tool Button */}
      <div className="mt-4 pt-3 border-t border-line flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Category Tag */}
          {category && (
            <span
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium bg-surface2 text-ink2 border border-line"
              title={`Category: ${category.name}`}
            >
              <CategoryIcon name={category.icon} className="w-3 h-3 text-accent" />
              <span className="truncate max-w-[110px]">{category.name}</span>
            </span>
          )}

        </div>

        {/* Primary Open Tool Button */}
        <button
          type="button"
          id={`btn-open-${tool.id}`}
          onClick={() => onOpen(tool)}
          className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-accent hover:bg-accent-hover active:bg-accent-hover text-accent-ink font-medium text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer ml-auto"
        >
          <span>Open Tool</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
