'use client';

import React from 'react';
import { Star, SlidersHorizontal } from 'lucide-react';
import { Category, Tool } from '@/lib/types';
import { CategoryIcon } from './CategoryIcon';

interface CategoryFilterProps {
  categories: Category[];
  tools: Tool[];
  selectedCategoryId: string | null; // null means 'all'
  onSelectCategory: (categoryId: string | null) => void;
  favoritesOnly: boolean;
  onToggleFavoritesOnly: () => void;
  onOpenManageCategories: () => void;
}

const pillBase =
  'shrink-0 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold transition-colors cursor-pointer border';
const pillOff = 'bg-surface text-ink2 border-line hover:border-accent hover:text-ink';
const pillOn = 'bg-ink text-bg border-ink';

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  categories,
  tools,
  selectedCategoryId,
  onSelectCategory,
  favoritesOnly,
  onToggleFavoritesOnly,
  onOpenManageCategories,
}) => {
  const counts = React.useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of tools) map[t.categoryId] = (map[t.categoryId] || 0) + 1;
    return map;
  }, [tools]);

  const favoritesCount = React.useMemo(() => tools.filter((t) => t.isFavorite).length, [tools]);

  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 overflow-x-auto pb-1.5 no-scrollbar">
        {/* All */}
        <button
          type="button"
          id="filter-all-categories"
          onClick={() => onSelectCategory(null)}
          className={`${pillBase} ${selectedCategoryId === null ? pillOn : pillOff}`}
        >
          <span>All</span>
          <span className="opacity-70 font-mono text-[10px]">{tools.length}</span>
        </button>

        {/* Favorites (independent toggle, works together with a category) */}
        <button
          type="button"
          id="filter-favorites-only"
          aria-pressed={favoritesOnly}
          onClick={onToggleFavoritesOnly}
          className={`${pillBase} ${
            favoritesOnly ? 'bg-star text-[#17131f] border-star' : pillOff
          }`}
        >
          <Star
            className={`w-3.5 h-3.5 ${
              favoritesOnly ? 'fill-[#17131f] text-[#17131f]' : 'fill-star text-star'
            }`}
          />
          <span>Favorites</span>
          <span className="opacity-70 font-mono text-[10px]">{favoritesCount}</span>
        </button>

        <div className="w-px h-5 bg-line shrink-0 mx-0.5" />

        {categories.map((cat) => {
          const isSelected = selectedCategoryId === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              id={`filter-cat-${cat.id}`}
              onClick={() => onSelectCategory(isSelected ? null : cat.id)}
              className={`${pillBase} ${isSelected ? pillOn : pillOff}`}
            >
              <CategoryIcon name={cat.icon} className="w-3.5 h-3.5" />
              <span>{cat.name}</span>
              <span className="opacity-70 font-mono text-[10px]">{counts[cat.id] || 0}</span>
            </button>
          );
        })}

        <button
          type="button"
          id="btn-manage-categories-strip"
          onClick={onOpenManageCategories}
          title="Manage categories"
          className="shrink-0 inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-medium text-ink3 hover:text-ink border border-dashed border-line hover:border-accent transition-colors cursor-pointer"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Organize</span>
        </button>
      </div>
    </div>
  );
};
