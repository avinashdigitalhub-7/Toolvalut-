'use client';

import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '@/hooks/usePWAInstall';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      id="offline-banner"
      className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 z-50 flex items-center justify-between gap-3 bg-accent-soft text-star border border-star/40 px-4 py-2.5 rounded-xl shadow-2xl backdrop-blur-md text-xs font-medium"
    >
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 text-star shrink-0" />
        <span>Offline Mode: Working seamlessly from local storage</span>
      </div>
      <span className="w-2 h-2 rounded-full bg-star animate-ping shrink-0" />
    </div>
  );
};
