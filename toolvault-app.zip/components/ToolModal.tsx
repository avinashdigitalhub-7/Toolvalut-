'use client';

import React, { useState } from 'react';
import { X, Globe, Star, Check } from 'lucide-react';
import { Category, Tool } from '@/lib/types';
import { extractDomain, getFaviconUrl, normalizeUrl, isValidUrl } from '@/lib/storage';
import { CategoryIcon } from './CategoryIcon';

interface ToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (toolData: Omit<Tool, 'id' | 'createdAt'> & { id?: string }) => void;
  categories: Category[];
  initialTool?: Tool | null;
  defaultCategoryId?: string;
}

interface ToolModalFormProps {
  initialTool?: Tool | null;
  categories: Category[];
  defaultCategoryId?: string;
  onClose: () => void;
  onSave: (toolData: Omit<Tool, 'id' | 'createdAt'> & { id?: string }) => void;
}

const ToolModalForm: React.FC<ToolModalFormProps> = ({
  initialTool,
  categories,
  defaultCategoryId,
  onClose,
  onSave,
}) => {
  const [url, setUrl] = useState(initialTool?.url || '');
  const [name, setName] = useState(initialTool?.name || '');
  const [description, setDescription] = useState(initialTool?.description || '');
  const [categoryId, setCategoryId] = useState(
    initialTool?.categoryId || defaultCategoryId || categories[0]?.id || ''
  );
  const [isFavorite, setIsFavorite] = useState(initialTool?.isFavorite || false);
  const launchCount = initialTool?.launchCount || 0;
  const [lastOpenedAt] = useState<string | null>(initialTool?.lastOpenedAt || null);
  const [faviconError, setFaviconError] = useState(false);
  const [error, setError] = useState('');

  // Auto-detect favicon and auto-suggest name from domain
  const handleUrlBlur = () => {
    if (!url.trim()) return;
    const formatted = normalizeUrl(url);
    setUrl(formatted);
    setFaviconError(false);

    // If name is blank, infer a clean name from the domain
    if (!name.trim()) {
      const domain = extractDomain(formatted);
      if (domain) {
        const parts = domain.split('.');
        const domainName = parts[0] || '';
        if (domainName) {
          const capitalized = domainName.charAt(0).toUpperCase() + domainName.slice(1);
          setName(capitalized);
        }
      }
    }
  };

  const domain = extractDomain(url);
  const faviconPreviewUrl = url.trim() ? getFaviconUrl(url) : '';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Please enter a website URL');
      return;
    }
    if (!name.trim()) {
      setError('Please provide a tool name');
      return;
    }
    if (!categoryId) {
      setError('Please assign a category');
      return;
    }

    const finalUrl = normalizeUrl(url);
    if (!isValidUrl(finalUrl)) {
      setError('That does not look like a valid website address');
      return;
    }

    onSave({
      id: initialTool?.id,
      url: finalUrl,
      name: name.trim(),
      description: description.trim() || undefined,
      categoryId,
      isFavorite,
      launchCount,
      lastOpenedAt,
    });
    onClose();
  };

  return (
    <div
      id="tool-modal-dialog"
      className="w-full max-w-lg rounded-2xl bg-surface border border-line p-5 sm:p-6 shadow-2xl my-8 relative"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-line">
        <div>
          <h2 className="text-lg font-bold text-ink">
            {initialTool ? 'Edit Tool' : 'Add New Tool'}
          </h2>
          <p className="text-xs text-ink3 mt-0.5">
            {initialTool ? 'Update details for this tool' : 'Save an online tool to your vault'}
          </p>
        </div>
        <button
          type="button"
          id="btn-close-tool-modal"
          onClick={onClose}
          className="min-w-[36px] min-h-[36px] rounded-lg text-ink3 hover:text-ink hover:bg-surface2 flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {error && (
        <div className="mt-3 p-3 rounded-xl bg-danger-soft border border-danger/40 text-danger text-xs font-medium">
          {error}
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        {/* Website URL + Live Favicon Detection */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Website URL <span className="text-accent">*</span>
          </label>
          <div className="relative flex items-center">
            {/* Favicon preview box */}
            <div className="absolute left-3 w-6 h-6 rounded-md bg-surface2 border border-line flex items-center justify-center shrink-0 overflow-hidden">
              {faviconPreviewUrl && !faviconError ? (
                /* eslint-disable-next-line @next/next/no-img-element */
                <img
                  src={faviconPreviewUrl}
                  alt="Favicon"
                  onError={() => setFaviconError(true)}
                  className="w-4 h-4 object-contain"
                />
              ) : (
                <Globe className="w-3.5 h-3.5 text-ink3" />
              )}
            </div>
            <input
              type="text"
              id="input-tool-url"
              required
              placeholder="https://tinypng.com or tinypng.com"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                setFaviconError(false);
              }}
              onBlur={handleUrlBlur}
              className="w-full pl-11 pr-3 py-2.5 rounded-xl bg-bg border border-line text-ink placeholder-ink3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-colors font-mono"
            />
          </div>
          {domain && (
            <p className="mt-1 text-[11px] text-ink3 flex items-center gap-1">
              <span>Detected domain:</span>
              <span className="font-mono text-accent font-semibold">{domain}</span>
              <span className="text-ink3">· Favicon detected automatically</span>
            </p>
          )}
        </div>

        {/* Tool Name */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Tool Name <span className="text-accent">*</span>
          </label>
          <input
            type="text"
            id="input-tool-name"
            required
            placeholder="e.g. TinyPNG, ChatGPT, PDF24"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-bg border border-line text-ink placeholder-ink3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-colors font-medium"
          />
        </div>

        {/* Category Assignment */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Category <span className="text-accent">*</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-44 overflow-y-auto p-1 bg-bg rounded-xl border border-line">
            {categories.map((cat) => {
              const isSelected = categoryId === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategoryId(cat.id)}
                  className={`flex items-center gap-2 p-2 rounded-lg text-xs font-medium text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-accent text-accent-ink shadow-sm ring-1 ring-accent'
                      : 'bg-surface text-ink2 hover:bg-surface2 hover:text-ink border border-line'
                  }`}
                >
                  <CategoryIcon
                    name={cat.icon}
                    className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-accent-ink' : 'text-ink3'}`}
                  />
                  <span className="truncate">{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Optional Description */}
        <div>
          <label className="block text-xs font-semibold text-ink2 uppercase tracking-wider mb-1.5">
            Description <span className="text-ink3 font-normal">(Optional)</span>
          </label>
          <textarea
            id="input-tool-description"
            rows={2}
            placeholder="What do you use this tool for? (e.g. Compress high-res banner images)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-bg border border-line text-ink placeholder-ink3 text-xs focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-colors resize-none leading-relaxed"
          />
        </div>

        {/* Favorite Toggle & Launch Counter Info */}
        <div className="p-3 rounded-xl bg-bg border border-line flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              id="btn-modal-toggle-fav"
              onClick={() => setIsFavorite(!isFavorite)}
              className={`min-w-[36px] min-h-[36px] rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                isFavorite
                  ? 'bg-star/20 text-star border border-star/40'
                  : 'bg-surface2 text-ink3 hover:text-ink2 border border-line'
              }`}
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'fill-star text-star' : ''}`} />
            </button>
            <div>
              <span className="text-xs font-semibold text-ink block">Mark as Favorite</span>
              <span className="text-[11px] text-ink3">Quickly filter in your vault</span>
            </div>
          </div>

        </div>

        {/* Actions */}
        <div className="pt-2 flex items-center justify-end gap-2.5">
          <button
            type="button"
            id="btn-cancel-tool"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-line text-ink2 hover:bg-surface2 hover:text-ink text-xs font-medium transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="btn-save-tool"
            className="px-5 py-2.5 rounded-xl bg-accent hover:bg-accent-hover active:bg-accent-hover text-accent-ink text-xs font-semibold shadow-md shadow-accent/20 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>{initialTool ? 'Save Changes' : 'Add to Vault'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export const ToolModal: React.FC<ToolModalProps> = (props) => {
  if (!props.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto tv-fade">
      <ToolModalForm
        key={props.initialTool?.id || 'new-tool'}
        initialTool={props.initialTool}
        categories={props.categories}
        defaultCategoryId={props.defaultCategoryId}
        onClose={props.onClose}
        onSave={props.onSave}
      />
    </div>
  );
};
