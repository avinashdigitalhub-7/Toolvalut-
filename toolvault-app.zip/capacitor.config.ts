import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.toolvault.app',
  appName: 'ToolVault',
  webDir: 'out', // Next.js static export folder
  backgroundColor: '#faf6ee',
  android: {
    allowMixedContent: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
    },
  },
};

export default config;
